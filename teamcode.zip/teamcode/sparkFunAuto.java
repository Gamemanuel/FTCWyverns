package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "sparkfuntest", group = "auto")
public class sparkFunAuto extends LinearOpMode {
    Library collection = new Library();
    RobotClass robot;

    @Override
    public void runOpMode() throws InterruptedException {
        // Get a reference to the sensor
        robot = new RobotClass(hardwareMap);
        // All the configuration for the OTOS is done in this helper method, check it out!
        configureOtos();
        // Wait for the start button to be pressed
        waitForStart();
        while (!isStopRequested()) {
            // Get the latest position, which includes the x and y coordinates, plus the
            // heading angle
            SparkFunOTOS.Pose2D pos = robot.myOtos.getPosition();
            //so we can see it is working:
            // Log the position to the telemetry
            telemetry.addData("X coordinate", pos.x); // forward
            telemetry.addData("Y coordinate", pos.y); // would be straifing or drift
            telemetry.addData("Heading angle", pos.h); //turning
            // Update the telemetry on the driver station
            telemetry.update();
            // Reset the tracking algorithm - this resets the position to the origin,
            // but can also be used to recover from some rare tracking errors
            // myOtos.resetTracking();
        }
    }

    private void configureOtos() {
        robot.myOtos.setLinearUnit(DistanceUnit.INCH);
        robot.myOtos.setAngularUnit(AngleUnit.DEGREES);
        // set offset if needed
        SparkFunOTOS.Pose2D offset = new SparkFunOTOS.Pose2D(0, 0, 0);
        robot.myOtos.setOffset(offset);
        //adjustments if needed
        robot.myOtos.setLinearScalar(1.0);
        robot.myOtos.setAngularScalar(1.0);
        //calibrate
        robot.myOtos.calibrateImu();
    }
}




