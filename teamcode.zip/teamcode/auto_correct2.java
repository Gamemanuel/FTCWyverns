package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "AutoTest_2", group = "auto")
public class auto_correct2 extends LinearOpMode {
    RobotClass robot;

    @Override
    public void runOpMode() throws InterruptedException {

        robot = new RobotClass(hardwareMap);
        robot.frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);


        waitForStart();
        //turnUntilAngle(90);
        superStraight(.45, 90, 500);


    }

    public void stopMotors() {
        robot.frontLeft.setPower(0);
        robot.frontRight.setPower(0);
        robot.backLeft.setPower(0);
        robot.backRight.setPower(0);
    }

    public void turnUntilAngle(double angle) throws InterruptedException {
        boolean finish = false;
        double turnVal = 1;
        double maxErrorAllowed = .25;
        double powerReduce = .6;
        double angularDistance;

        while (!finish) {
            opModeIsActive();
            angularDistance = Math.min(Math.abs(robot.getHeading() - angle), Math.abs((180 - Math.abs(robot.getHeading())) + (180 - Math.abs(angle))));


            telemetry.addData("angularDistance", angularDistance);
            telemetry.addData("currentAngle", robot.getHeading());
            telemetry.addData("Power", turnVal);
            telemetry.addData("power reduce", powerReduce);
            telemetry.addData("isDone", finish);
            telemetry.update();

            double currentAngle = robot.getHeading();
            if (currentAngle < 0) {//if negative
                currentAngle += 360;
            }

            if (currentAngle >= angle) {
                if ((currentAngle - angle) <= 180) {
                    //right
                    turnVal = powerReduce;
                } else {
                    //left
                    turnVal = -powerReduce;
                }
            } else {
                if (angle - currentAngle <= 180) {
                    //left
                    turnVal = -powerReduce;
                } else {
                    //right
                    turnVal = powerReduce;
                }
            }

            robot.frontLeft.setPower(turnVal);
            robot.frontRight.setPower(turnVal);
            robot.backLeft.setPower(turnVal);
            robot.backRight.setPower(turnVal);
            if (angularDistance <= (1)) {
                powerReduce = .38;
                if (angularDistance <= (maxErrorAllowed)) {
                    telemetry.addData("isDone", finish);
                    telemetry.update();
                    finish = true;
                    powerReduce = .27;
                    stopMotors();

                }
            }
        }


    }

    public void superStraight(double power, double heading, long time) throws InterruptedException {
        boolean finish = false;
        double perError;
        while (!finish) {
            telemetry.addData("Time", System.currentTimeMillis());
            perError = Math.abs(Math.abs((robot.getHeading() - heading) / robot.getHeading())) - 1;
            telemetry.addData("% Error", perError);
            telemetry.addData("Angle", robot.getHeading());
            telemetry.update();
            if (robot.getHeading() > heading) {
                robot.frontLeft.setPower(-power);
                robot.frontRight.setPower(power * perError);
                robot.backLeft.setPower(-power);
                robot.backRight.setPower(power * perError);
            } else {
                robot.frontLeft.setPower(power * perError);
                robot.frontRight.setPower(-power);
                robot.backLeft.setPower(power * perError);
                robot.backRight.setPower(-power);
            }
//            if (System.currentTimeMillis() >= time) {
//                stopMotors();
//                finish = true;
//            }
        }
        }
    }