package org.firstinspires.ftc.teamcode;

public class Library {
    double[] wheelSpeeds = new double[2];
    double liftSpeed;

    //index 0 == leftSide power
    //index 1 == rightSide power
    public double[] getWheelSpeeds() {
        return wheelSpeeds;
    }
    public void regularDrive( double forward, double turn ) {
        wheelSpeeds[0] = forward - (turn * 0.75);
        wheelSpeeds[1] = forward + (turn * 0.75);
    }

    public void tankDrive( double left, double right ) {
        wheelSpeeds[0] = left;
        wheelSpeeds[1] = right;
    }
}