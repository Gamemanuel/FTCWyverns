package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@com.qualcomm.robotcore.eventloop.opmode.Autonomous(name = "AutoTest2", group = "auto")
public class auto_correct extends LinearOpMode {
    Library collection = new Library();
    RobotClass robot;
    double angularDistance;

    @Override
    public void runOpMode() throws InterruptedException {
        robot = new RobotClass(hardwareMap);
        robot.frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        robot.resetIMU();
        configureOtos();
        waitForStart();
//        autoRegularDrive(0.25, 0, 500);
//        turnUntilAngle(270);
//        autoRegularDrive(0.3, 0, 3200);
////        far park code
//        autoRegularDrive(0.25, 0, 500);
//        turnUntilAngle(330);
//        autoRegularDrive(0.3, 0, 1500);
//        //hang specimen
//        autoRegularDrive(-0.3, 0, 1400);
//        turnUntilAngle(270);
//        autoRegularDrive(0.25, 0, 300);
        // current code
        NearPerfectDrive(24, .3);
    }

    public void stopMotors() {
        robot.frontLeft.setPower(0);
        robot.frontRight.setPower(0);
        robot.backLeft.setPower(0);
        robot.backRight.setPower(0);
    }

    public void turnUntilAngle(double angle) {
        boolean finish = false;
        double turnVal = 1;
        double maxErrorAllowed = .15;
        double powerReduce = .4;
        while (!finish) {
            opModeIsActive();
            angularDistance = Math.min(Math.abs(robot.getHeading() - angle), Math.abs((180 - Math.abs(robot.getHeading())) + (180 - Math.abs(angle))));
            telemetry.addData("angularDistance", angularDistance);
            telemetry.addData("currentAngle", robot.getHeading());
            telemetry.addData("Power", turnVal);
            telemetry.addData("power reduce", powerReduce);
            telemetry.addData("isDone", finish);
            telemetry.update();
            double currentAngle = robot.getHeading();
            if (currentAngle < 0) {//if negative
                currentAngle += 360;
            }
            if (currentAngle >= angle) {
                if ((currentAngle - angle) <= 180) {
                    //right
                    turnVal = powerReduce;
                } else {
                    //left
                    turnVal = -powerReduce;
                }
            } else {
                if (angle - currentAngle <= 180) {
                    //left
                    turnVal = -powerReduce;
                } else {
                    //right
                    turnVal = powerReduce;
                }
            }
            robot.frontLeft.setPower(turnVal);
            robot.frontRight.setPower(turnVal);
            robot.backLeft.setPower(turnVal);
            robot.backRight.setPower(turnVal);
            if (angularDistance <= 1) {
                powerReduce = .20;
                if (angularDistance <= (maxErrorAllowed)) {
                    telemetry.addData("isDone", finish);
                    telemetry.update();
                    finish = true;
                    stopMotors();
                }
            }
        }
    }

    public void autoRegularDrive(double Forward, double Turn, long time) throws InterruptedException {
        collection.regularDrive(-Forward, Turn);
        double[] wheelSpeeds = collection.getWheelSpeeds();
        robot.frontLeft.setPower(-wheelSpeeds[0]);
        robot.frontRight.setPower(wheelSpeeds[1]);
        robot.backLeft.setPower(-wheelSpeeds[0]);
        robot.backRight.setPower(wheelSpeeds[1]);
        sleep(time);
        collection.regularDrive(0, 0);
        robot.frontLeft.setPower(-wheelSpeeds[0]);
        robot.frontRight.setPower(wheelSpeeds[1]);
        robot.backLeft.setPower(-wheelSpeeds[0]);
        robot.backRight.setPower(wheelSpeeds[1]);
    }

    private void configureOtos() {
        robot.myOtos.setLinearUnit(DistanceUnit.INCH);
        robot.myOtos.setAngularUnit(AngleUnit.DEGREES);
        // set offset if needed
        SparkFunOTOS.Pose2D offset = new SparkFunOTOS.Pose2D(0, 0, 0);
        robot.myOtos.setOffset(offset);
        //adjustments if needed
        robot.myOtos.setLinearScalar(1.0);
        robot.myOtos.setAngularScalar(1.0);
        //calibrate
        robot.myOtos.calibrateImu();
    }

    private void NearPerfectDrive(double distanceForward, double forwardPower) {
        //this is set in inches because we are american
        robot.myOtos.resetTracking();
        SparkFunOTOS.Pose2D pos = robot.myOtos.getPosition();
        distanceForward -= 4.5;
        double startingPos = pos.x;
        double EndPos = startingPos + distanceForward;
        boolean finish = false;
        double maxErrorAllowed = .25;
        double distanceRemaining;
        if (distanceForward < 0) {
            forwardPower = -forwardPower;
            distanceForward = Math.abs(distanceForward);
        }
        while (!finish) {
            robot.frontLeft.setPower(forwardPower);
            robot.frontRight.setPower(-forwardPower);
            robot.backLeft.setPower(forwardPower);
            robot.backRight.setPower(-forwardPower);
            SparkFunOTOS.Pose2D pos2 = robot.myOtos.getPosition();
            distanceRemaining = distanceForward - (Math.abs(pos2.x) - Math.abs(startingPos));
            telemetry.addLine("STARTING");
            telemetry.addData("current", pos2.x);
            telemetry.addData("distance left", distanceRemaining);
            telemetry.update();
            if (distanceRemaining <= 1) {
                forwardPower = .25;
                if (distanceRemaining <= maxErrorAllowed) {
                    stopMotors();
                    finish = true;
                }
            }
        }
    }
}