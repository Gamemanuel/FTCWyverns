package org.firstinspires.ftc.teamcode;

import android.annotation.SuppressLint;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

// adds to list of teleop programs
@TeleOp(name = "SixWheel", group = "driving")
// this is just for six wheel
public class    SixWheel extends LinearOpMode {
    Library collection = new Library();
    RobotClass robot;
    double angle;
    public void turnUntilAngle(double angle) {
        boolean finish = false;
        double turnVal = 1;
        double maxErrorAllowed = .15;
        double powerReduce = .4;
        double angularDistance;
        while (!finish) {
            opModeIsActive();
            angularDistance = Math.min(Math.abs(robot.getHeading() - angle), Math.abs((180 - Math.abs(robot.getHeading())) + (180 - Math.abs(angle))));
            telemetry.addData("angularDistance", angularDistance);
            telemetry.addData("currentAngle", robot.getHeading());
            telemetry.addData("Power", turnVal);
            telemetry.addData("power reduce", powerReduce);
            telemetry.addData("isDone", finish);
            telemetry.update();
            double currentAngle = robot.getHeading();
            if (currentAngle < 0) {//if negative
                currentAngle += 360;
            }
            if (currentAngle >= angle) {
                if ((currentAngle - angle) <= 180) {
                    //right
                    turnVal = powerReduce;
                } else {
                    //left
                    turnVal = -powerReduce;
                }
            } else {
                if (angle - currentAngle <= 180) {
                    //left
                    turnVal = -powerReduce;
                } else {
                    //right
                    turnVal = powerReduce;
                }
            }
            robot.frontLeft.setPower(turnVal);
            robot.frontRight.setPower(turnVal);
            robot.backLeft.setPower(turnVal);
            robot.backRight.setPower(turnVal);
            if (angularDistance <= 1) {
                powerReduce = .20;
                if (angularDistance <= (maxErrorAllowed)) {
                    telemetry.addData("isDone", finish);
                    telemetry.update();
                    finish = true;
                    stopMotors();
                }
            }
        }
    }
    // makes it so i can access the the motors from different children classes
    @SuppressLint("DefaultLocale")
    @Override
    public void runOpMode() {
        RobotClass robot = new RobotClass(hardwareMap);
        //waits for start
        waitForStart();
        while (opModeIsActive()) {
            //put all of the code in here
            collection.regularDrive(gamepad1.left_stick_y, 0);
            double[] wheelSpeeds = collection.getWheelSpeeds();

            robot.frontLeft.setPower(-wheelSpeeds[0]);
            robot.frontRight.setPower(wheelSpeeds[1]);
            robot.backLeft.setPower(-wheelSpeeds[0]);
            robot.backRight.setPower(wheelSpeeds[1]);
            robot.liftLeft.setPower(gamepad2.right_stick_y);
            robot.liftRight.setPower(gamepad2.right_stick_y);
            angle = Math.atan2(gamepad1.right_stick_x, gamepad1.right_stick_y);
            if (Math.abs(gamepad1.right_stick_x + gamepad1.right_stick_y) > 0.2) {
                turnUntilAngle(angle);
            }

            telemetry.addLine(String.format("heading: %4.3f", robot.getHeading()));
            telemetry.update();
        }
    }
    public void stopMotors() {
        robot.frontLeft.setPower(0);
        robot.frontRight.setPower(0);
        robot.backLeft.setPower(0);
        robot.backRight.setPower(0);
    }
}